param (
    [string]$ServiceName
)

# 관리자 권한으로 실행되었는지 확인
if (-not ([bool](Get-Process -Id $PID -IncludeUserName | Where-Object { $_.UserName -ne $null }))) {
    Write-Output "이 PowerShell 스크립트를 관리자 권한으로 실행해야 합니다."
    exit
}

# 서비스 이름 설정
$serviceName = $ServiceName

# 서비스 중지
Write-Output "Stopping service: $serviceName"
Stop-Service -Name $serviceName -Force

# 서비스 시작 유형을 '사용 안 함'으로 변경
Write-Output "Configuring service: $serviceName"
Set-Service -Name $serviceName -StartupType Disabled

# 실패 동작 설정
Write-Output "Configuring failure actions for service: $serviceName"
$servicePath = "HKLM:\SYSTEM\CurrentControlSet\Services\$serviceName"

# 실패 동작을 동작하지 않음으로 설정
$failureActions = @(
    [byte]0x00 # 첫째 실패 동작: 동작하지 않음
    [byte]0x00 # 둘째 실패 동작: 동작하지 않음
    [byte]0x00 # 후속 실패 동작: 동작하지 않음
)

# 레지스트리에 실패 동작 값 설정
Set-ItemProperty -Path $servicePath -Name "FailureActions" -Value $failureActions

# 서비스 상태 확인
Write-Output "Checking service status: $serviceName"
Get-Service -Name $serviceName

Write-Output "Done."
