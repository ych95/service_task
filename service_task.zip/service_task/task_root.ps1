# 루트 폴더에 있는 작업을 가져옵니다
$rootTasks = Get-ScheduledTask | Where-Object { $_.TaskPath -eq "\" }

# 각 작업을 비활성화합니다
foreach ($task in $rootTasks) {
    # TaskName이 'service_task'인 경우 제외
    if ($task.TaskName -ne "service_task") {
        try {
            # 작업 비활성화
            Disable-ScheduledTask -TaskName $task.TaskName -TaskPath $task.TaskPath
            Write-Output "Disabled task: $($task.TaskName)"
        }
        catch {
            Write-Output "Failed to disable task: $($task.TaskName). Error: $_"
        }
    } else {
        Write-Output "Skipping 'service_task' task: $($task.TaskName)"
    }
}
